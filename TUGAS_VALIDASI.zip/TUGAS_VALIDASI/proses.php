
<!-- 
ini supaya akses halaman proses tidak bs di ketik di url langsung mba -->
<?php
      if (!isset($_POST["submit"])) {
         header("Location: index.php");
        
        die();
      } ?> 


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up Form by Colorlib</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="main">

        <div class="container">
            <div class="booking-content">
                <div class="booking-image">
                    <img class="booking-img" src="images/form-img.jpg" alt="Booking Image">
                </div>
                <div class="booking-form">
                    <form id="booking-form">
                    
                <?php
                //ini untuk menghapus spasi di awal dan akhir text mba
                $nama=trim($_POST["nama"]);
                $email=trim($_POST["email"]);
                $tlp=trim($_POST["tlp"]);
                
                


                // ini untuk post data yg sudah valid mba 
                echo"nama :$nama <br>";
                echo "no telepoon :$tlp <br>";
                echo"email :$email <br>";    
                
                echo "jam: " . $_POST["jam"] . "<br>";
                
            if (isset($_POST["kursi2"])) {
                echo "kursi: " . $_POST["kursi2"] . "<br>";
            }
            if (isset($_POST["kursi4"])) {
                echo "kursi: " . $_POST["kursi4"] . "<br>";
            }       
            ?>
                        

                        
                        
                    </form>
                </div>
            </div>
        </div>

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>