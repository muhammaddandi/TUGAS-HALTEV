


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>booking meja</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="main">

        <div class="container">
            <div class="booking-content">
                <div class="booking-image">
                    <img class="booking-img" src="images/form-img.jpg" alt="Booking Image">
                </div>
                <div class="booking-form">
                    <form id="booking-form" action="proses.php" method="post" >
                        <h2>Booking meja</h2>
                        <div class="form-group form-input">
                            <input type="text" name="nama" id="nama" value="" maxlength ="10" required/>
                            <label for="name" class="form-label">nama anda</label>
                        </div>

                        <div class="form-group form-input">
                            <input type="number" name="tlp" id="tlp" value="" required />
                            <label for="tlp" class="form-label">no telp</label>
                        </div>


                        <div class="form-group form-input">
                            <input type="email" name="email" id="name" value="" required/>
                            <label for="name" class="form-label">email</label >
                        </div>


                        
                        <div class="form-group">
                            <div class="select-list">
                                <select name="jam" id="jam" required>
                                <option value="">pilih jam</option>
                                    <option value="6pm">6:00 PM</option>
                                    <option value="7pm">7:00 PM</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-radio">
                            <label class="label-radio">pilih berapa kursi</label>
                            <div class="radio-item-list">
                                
                                <span class="radio-item">
                                    <input type="radio" name="kursi2" value="2" id="kursi2" checked/>
                                    <label for="number_people_2">2</label>
                                </span>
                                <span class="radio-item">
                                    <input type="radio" name="kursi4" value="4" id="kursi4"  />
                                    <label for="number_people_4">4</label>
                                </span>
                                
                                
                            </div>
                        </div>

                        <div class="form-submit">
                            <input type="submit" value="Book now" class="submit" id="submit" name="submit" />
                            <a href="#" class="vertify-booking">tekan tombol booking now jika data sudah benar</a>
                        </div>
                    </form>
                    </div?>
                </div>
            </div>
        </div>

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>